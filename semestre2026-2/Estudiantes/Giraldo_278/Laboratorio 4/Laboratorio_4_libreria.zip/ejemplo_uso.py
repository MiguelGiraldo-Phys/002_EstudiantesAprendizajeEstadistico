import numpy as np
import matplotlib.pyplot as plt
from mirl import ajustar_modelo, calcular_hipotesis

# 1. Datos del laboratorio
np.random.seed(42)
X = np.linspace(0, 1, 100)
y = 0.2 + 0.2*X + 0.02*np.random.random(100)

# 2. Usar nuestra nueva librería
alpha = 0.1
iteraciones = 5000
theta_0, theta_1, coste = ajustar_modelo(X, y, alpha, iteraciones)

print("=== Resultados de la Librería MIRL ===")
print(f"Intercepto (theta_0): {theta_0:.4f}")
print(f"Pendiente (theta_1) : {theta_1:.4f}")
print(f"Coste Final         : {coste:.6f}")

# 3. Graficar resultados
plt.scatter(X, y, color='blue', alpha=0.5, label='Datos Reales')
plt.plot(X, calcular_hipotesis(X, theta_0, theta_1), color='red', linewidth=2, label='Modelo MIRL')
plt.legend()
plt.show()