from setuptools import setup, find_packages

setup(
    name='mirl',
    version='0.1.0',
    description='Libreria para ajustar regresion lineal con gradiente descendente',
    author='Tu Nombre',
    packages=find_packages(),
    install_requires=['numpy'],
)