import numpy as np

def calcular_hipotesis(X, theta_0, theta_1):
    """
    Calcula la hipótesis lineal (predicción).
    Parámetros: X (datos), theta_0 (intercepto), theta_1 (pendiente).
    Retorna: Arreglo con las predicciones.
    """
    return theta_0 + theta_1 * X

def calcular_coste(X, y, theta_0, theta_1):
    """
    Calcula la función de coste (Error Cuadrático Medio).
    Parámetros: X (datos), y (etiquetas reales), theta_0, theta_1.
    Retorna: Valor numérico del coste.
    """
    m = len(y)
    predicciones = calcular_hipotesis(X, theta_0, theta_1)
    return (1 / (2 * m)) * np.sum((predicciones - y) ** 2)

def ejecutar_gradiente_descendente(X, y, alpha, iteraciones):
    """
    Ejecuta el gradiente descendente para optimizar los parámetros.
    Retorna: Tupla con los valores óptimos (theta_0, theta_1).
    """
    m = len(y)
    theta_0, theta_1 = 0.0, 0.0  # Inicialización
    
    for _ in range(iteraciones):
        predicciones = calcular_hipotesis(X, theta_0, theta_1)
        error = predicciones - y
        
        d_theta_0 = (1 / m) * np.sum(error)
        d_theta_1 = (1 / m) * np.sum(error * X)
        
        theta_0 -= alpha * d_theta_0
        theta_1 -= alpha * d_theta_1
        
    return theta_0, theta_1

def ajustar_modelo(X, y, alpha=0.1, iteraciones=1000):
    """
    Función principal que envuelve todo el proceso de ajuste.
    Retorna: theta_0, theta_1 y el coste final.
    """
    theta_0, theta_1 = ejecutar_gradiente_descendente(X, y, alpha, iteraciones)
    coste_final = calcular_coste(X, y, theta_0, theta_1)
    return theta_0, theta_1, coste_final