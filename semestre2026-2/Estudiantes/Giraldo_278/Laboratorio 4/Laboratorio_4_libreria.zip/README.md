# Mi Regresión Lineal (MIRL)

Una librería en Python para realizar regresiones lineales utilizando el algoritmo de Gradiente Descendente.

## Instalación
Para instalar la librería localmente, abre tu terminal en la carpeta principal y ejecuta:
`pip install -e .`

## Uso Básico
Importa el modelo y ajusta tus datos fácilmente:
```python
import numpy as np
from mirl import ajustar_modelo

X = np.array([1, 2, 3])
y = np.array([2, 4, 6])
t0, t1, coste = ajustar_modelo(X, y, alpha=0.1, iteraciones=100)
